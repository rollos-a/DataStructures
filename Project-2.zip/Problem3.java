            //import java.util.Scanner;

public class Problem3{

    public static void main(String args[]){

    //objects 
    BigO bigO = new BigO();
    int test1 = 1;
    int test2 = 9;
    int test3 = 20;
    long startTime, endTime, timer;

    /* Ignore this chunk ... might use it later
    Scanner scan = new Scanner(System.in);
    System.out.println("Input value for ~n~: ");
    int valueN = scan.nextInt();
    System.out.println("you input "+valueN+" for ~n~");
    bigO.constant(valueN);
    */

    //measure runtimes
        //3 runtime measurements for (O(1))  
    startTime = System.nanoTime();
    bigO.constant(test1);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CONSTANT runtime1: " + timer);

    startTime = System.nanoTime();
    bigO.constant(test2);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CONSTANT runtime2: " + timer);

    startTime = System.nanoTime();
    bigO.constant(test3);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CONSTANT runtime3: " + timer);

    //3 runtime measurements for cubic
    startTime = System.nanoTime();
    bigO.cubic(test1);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CUBIC runtime1: " + timer);

    startTime = System.nanoTime();
    bigO.cubic(test2);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CUBIC runtime2: " + timer);

    startTime = System.nanoTime();
    bigO.cubic(test3);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("CUBIC runtime3: " + timer);

    //3 runtime measurements for exponential
    startTime = System.nanoTime();
    bigO.exp(test1);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("EXP runtime1: " + timer);

    startTime = System.nanoTime();
    bigO.exp(test2);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("EXP runtime2: " + timer);

    startTime = System.nanoTime();
    bigO.exp(test3);
    endTime = System.nanoTime();
    timer = endTime - startTime;
    System.out.println("EXP runtime3: " + timer);
    }
}