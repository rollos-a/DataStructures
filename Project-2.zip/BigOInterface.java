public interface BigOInterface {

	public void cubic(int n);
	public void exp(int n);
	public void constant(int n);
    
}
