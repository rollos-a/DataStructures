
public class StackTester{
    public static void main(String args[]){

        //objects
            //should i be writing Integer into generic class?
            //how can i keep the datatype generic? <-- ask Lucas?
        
            //MyStack<Integer> stackClass = new MyStack<>();
        MyStack stackClass = new MyStack<>();

        //int array2[] = {1, 2, 3}; 
        //int array3[] = {1, 2, 3, 4, 5}; 
        //int array4[] = {1, 2, 3, 4, 5, 6, 7, 8}; 
        //int array5[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}; 
        
        System.out.println(stackClass.isEmpty());
        boolean x = true;
        stackClass.push(x);
        x = true;
        stackClass.push(x);
        x = false;
        stackClass.push(x);
        System.out.println(stackClass.pop());
        System.out.println(stackClass.pop());
        System.out.println(stackClass.pop());
        // System.out.println(stackClass.isEmpty());
        // System.out.println(stackClass.peek());
        // System.out.println(stackClass.size());
        // System.out.println(stackClass.pop());
        // System.out.println(stackClass.pop());
        // System.out.println(stackClass.peek());
        // System.out.println(stackClass.pop());



        //stackClass.pop(array1);
        //stackClass.peek(array1);
        //stackClass.isEmpty(array1);
        //stackClass.size(array1);

        /*
        public void push(T x);
	    public T pop();
	    public T peek();
	    public boolean isEmpty();
	    public int size();
        */
    }
}