
public class MyStack<T> implements MyStackInterface<T>{
    private int size;
    private Object[] arr;
    /*
    //i think get rid of the below
    String s = args
    // to here 
    Scanner sc = new Scanner(System.in);
        System.out.println("Enter an int for stack size");
        int sizzle = sc.nextLine();
    // to here ???   
    */

    public MyStack(){
        size = 0;
        arr = new Object[5];
    }

    @Override
    public void push(T x){
        if (size == arr.length){
            Object[] newArr = new Object[arr.length*2];
            for (int m=0; m<size; m++){
                newArr[m] = arr[m];
            }
            arr = newArr;
        }
        arr[size] = x;
        size++;
    }

    @Override
	public T pop(){
        if (size == 0){
            System.out.println("StackUnderflow");
            return null;
        }
        T seezee = (T) arr[size-1];
        size--;
        return seezee;
    }

    @Override    
	public T peek(){
        return (T) arr[size-1];
    }
    
    @Override
    public int size(){
            return size;
        }

    @Override
	public boolean isEmpty(){
        return size()==0;
    }
	



}