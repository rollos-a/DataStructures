public interface PalindromeInterface {

    public boolean isPalindrome(String x);

}