
public class Palindrome implements PalindromeInterface{

    MyStack stack = new MyStack<>();
    String reverse = "";
    //char ch;

    public boolean isPalindrome(String x){
        x = x.toLowerCase();
        x = x.replaceAll("\\s", "");
        for (int i = 0; i<x.length(); i++) {
            stack.push(x.charAt(i));
        }
        int size = stack.size();
        for (int i=0; i<size; i++){
            reverse += stack.pop();
        }

        if (x.equals(reverse)){
            return true;
        }
        return false;
        // int test = 0;
        // for (int i=0; i<stack.size(); i++){
        //     if (stack[i].equals(reverse[i]) != true){
        //         test++;
        //     }
        // }
        // if (test == 0){
        //     return true;
        // }
        // else{
        //     return false;
        // }

    }
}
