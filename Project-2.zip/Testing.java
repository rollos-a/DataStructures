
public class Testing {  
    public static void main(String[] args) {  
        // Initialize three codepoints: cp1, cp2 and cp3  
                
                char cp1 = char() " ";  
                
       // Check whether the codepoints are whitespaces or not.  
                boolean check1 = Character.isWhitespace(cp1);  
                
                
        if(check1){  
        System.out.print("The codepoint \'"+cp1+"\' is a whitespace character.\n");  
        }  }}