import java.util.ArrayList;
import java.util.*;
import java.util.PriorityQueue;

public class Main{

    public static void main(String[] args){
         /*
        SpellChecker sCheck = new SpellChecker("/home/codio/workspace/words.txt");
        List<String> incor = sCheck.getIncorrectWords("/home/codio/workspace/test.txt");
        //System.out.println(incor);
        
        for(String x : incor){
            Set<String> surge = sCheck.getSuggestions(x);
            System.out.println("Suggestions for " + x + " : " + surge);
        }
        //System.out.println("Suggestions: " + sCheck.getSuggestions());
        
        //ArrayList<String> soup = new ArrayList<String>(sCheck.getSuggestions("istant"));
        
        //System.out.println(soup);//(sCheck.getSuggestions("horiozn"));
            //System.out.println("Spelling error: " + ) come back to gabi when write incorrectword method 
        
        //System.out.println("here ya go: " + sCheck.offerSugg(soup, sCheck.hashSet));
        
         */

        // /*
        KBestCounter<Integer> kount = new KBestCounter<>(4);
        kount.count(129);
        kount.count(-32);
        kount.count(0);
        //PriorityQueue<Integer> copyQ = new PriorityQueue<>(kount.queen);    
        kount.count(33);
        kount.count(222);
        kount.count(-3);
        kount.count(4);
        System.out.println("///////////");
        //copyQ = new PriorityQueue<>(kount.queen); 

        //System.out.println("okurr: " + kount.queen.size());
        System.out.println(kount.kbest());
        System.out.println("round two");
        System.out.println(kount.kbest());
        //while (!kount.queen.isEmpty()){
        //    System.out.println("qq: " + kount.queen.poll());
        //}
        // */

    // javac SpellChecker.java && javac Main.java
    }

}