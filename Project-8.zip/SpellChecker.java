import java.util.*;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.ArrayList;



public class SpellChecker implements SpellCheckerInterface{

    //private Set<String> wtf;

    private String fileName;
    private HashSet<String> hashSet;

        //constructor 
    public SpellChecker(String fileN){
        fileName = fileN;
        hashSet = new HashSet<>();
        ArrayList<String> ariana = new ArrayList<String>();
        try{
        FileReader fileRead = new FileReader(fileName);
        BufferedReader buffy = new BufferedReader(fileRead);
        StringBuilder stringBob = new StringBuilder();
        int blube;

        while ((blube = buffy.read()) != -1){
                // 9:12
            String bob = stringBob.toString();
            if(blube != -1 && bob.length() != 0){
                ariana.add(bob);
            }

            stringBob = new StringBuilder();
            while((blube != -1) && (blube != 10) && (!Character.isWhitespace((char) blube))){
                if(Character.isLowerCase((char) blube)){
                    stringBob.append((char) blube);
                }
                if(Character.isUpperCase(blube)){
                    stringBob.append(Character.toLowerCase((char) blube));
                }
                
                //blube = buffy.read();
                if((blube = buffy.read()) == -1){
                    System.out.println("-1 found");
                    bob = stringBob.toString(); // took out 'String' from the beginning
                    System.out.println("last stringBob: " + bob);
                    ariana.add(bob);
                }
            }
                // did this 9:12
            /*String bob = stringBob.toString();
            if(blube != -1 && bob.length() != 0){
                ariana.add(bob);
            }*/
            
            
            //System.out.println("stringBob: " + bob);
        }buffy.close();
        //HashSet<String> hashSet = new HashSet<>(ariana);
        
        for (String x : ariana){
        //    System.out.println("araina: " + x);
            hashSet.add(x);
        }
        for (String x : hashSet){
            //System.out.println("hash: " + x);
        }
        
        } catch(FileNotFoundException e){
            System.out.println("File not found: " + fileName);
        } catch(IOException e){
            System.out.println("Error w file: " + fileName);
        }
    }

    
    // methods from interface
    public List<String> getIncorrectWords(String filename){
        fileName = filename;
        //wtf = new HashSet<>();
        ArrayList<String> testies = new ArrayList<String>();
        try{
        FileReader fileRead = new FileReader(fileName);
        BufferedReader buffy = new BufferedReader(fileRead);
        StringBuilder stringBob = new StringBuilder();
        int blube;

        while ((blube = buffy.read()) != -1){
            stringBob = new StringBuilder();
            while((blube != -1) && (blube != 10) && (!Character.isWhitespace((char) blube))){
                if(Character.isLowerCase((char) blube)){
                    stringBob.append((char) blube);
                }
                if(Character.isUpperCase(blube)){
                    stringBob.append(Character.toLowerCase((char) blube));
                }
                if(Character.isDigit(blube)){
                    stringBob.append((char) blube);
                }
                blube = buffy.read();
                /*if(blube == -1){
                    //System.out.println("-1 found");
                    String bob = stringBob.toString();
                    //System.out.println("last stringBob: " + bob);
                    testies.add(bob);
                }*/
            }
            String bob = stringBob.toString();
            if(blube != -1 && bob.length() != 0){
                testies.add(bob);
            }    
        }buffy.close();
        
        //for (String x : testies){
        //    System.out.println("testies: " + x);
        //}
        }
        catch(FileNotFoundException e){System.out.println("File not found: " + fileName);} 
        catch(IOException e){System.out.println("Error w file: " + fileName);}
        
        ArrayList<String> mispelled = new ArrayList<>();
        for (String x : testies){
            if (!hashSet.contains(x)){
                mispelled.add(x);
            }
        }
        return mispelled;
        
    }

	public Set<String> getSuggestions(String word){
        Set<String> suggies = new HashSet<>();
        String dumie = word.replaceAll("\\d", "");
        suggies.add(dumie);

        for(int i = 0; i<= dumie.length(); i++){
            for(char x = 'a'; x <= 'z'; x++){
                String suggW = dumie.substring(0, i) + x + dumie.substring(i);
                suggies.add(suggW);
            }

            for(int y = 0; y< dumie.length(); y++){
                String suggWo = dumie.substring(0, y) + dumie.substring(y+1);
                suggies.add(suggWo);
            }

            for(int z = 0; z< dumie.length()-1; z++){
                String suggWor = dumie.substring(0, z) + dumie.substring(z+1, z+2) + dumie.substring(z, z+1) + dumie.substring(z+2);
                suggies.add(suggWor);
            }

            /*
                // unlocksies
            for(int mlk = 0; mlk < word.length(); mlk++){
                String suggWord = word.substring(mlk);
                suggies.add(suggWord);
            }

                // unlocksies
            for(int o = word.length()-1 ; o >= 0; o--){
                String suggWordl = word.substring(0, o);
                suggies.add(suggWordl);
            }
            */
        }
       Set<String> finitto = new HashSet<>();
        for(String x : suggies){
            if(hashSet.contains(x)){
                finitto.add(x);
            }
        }

        return finitto;
    }
        // dead
    private Set<String> offerSugg(ArrayList<String> sugs, HashSet<String> dict){
        Set<String> offerSet = new HashSet<>();
        for(String x : sugs){
            if(hashSet.contains(x)){
                offerSet.add(x);
            }
        }
        return offerSet;
    }
}


