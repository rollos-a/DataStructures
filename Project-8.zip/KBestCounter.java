import java.util.*;
import java.util.PriorityQueue;

public class KBestCounter<T extends Comparable<? super T>> implements KBest<T>{
    private PriorityQueue<T> queen;
    private int k;
        // constructor
    public KBestCounter(int k){
        this.k = k;
        queen = new PriorityQueue<T>(this.k);
    }

	public void count(T x){
        if(queen.size() < this.k){
            queen.offer(x);
        }
        else if (queen.peek().compareTo(x)<0){
            queen.poll();
            queen.offer(x);
        }
    }

	public List<T> kbest(){
        ArrayList<T> lick = new ArrayList<T>(queen);
        Collections.sort(lick);
        return lick;
    }

}