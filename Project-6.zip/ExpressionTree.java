import java.util.LinkedList;

public class ExpressionTree implements ExpressionTreeInterface{
    
    private static class ExpressionNode{
            //class notes
        String data;
        char operator;
        int operand;
        ExpressionNode left;
        ExpressionNode right;

        ExpressionNode(String d){
            data = d;
            left = null;
            right = null;
        }
    }
    
    public ExpressionNode root = null;

        //constructor for ExpressionTree class  
    public ExpressionTree(String expr){
        String expression = expr;
        //ExpressionNode root; //class notes (but not private)

        LinkedList<ExpressionNode> linky = new LinkedList<ExpressionNode>();
        String[] lumps = expression.split(" ");
        int pook = 0; //horri
            for (String x:lumps){
                if(operatorM(x)){
                    if (linky.size()<2){
                        throw new IllegalArgumentException("not enough operands");
                    }
                    ExpressionNode right = linky.removeLast();
                    ExpressionNode left = linky.removeLast();
                    ExpressionNode operator = new ExpressionNode(x);
                    operator.data = x;
                    operator.right = right;
                    operator.left = left;
                    linky.addLast(operator);
//System.out.println("linky size" + linky.size());

//String rRight = operator.right.data;
//System.out.println("linky last: " + rRight);
                }
                
                else{
                    try{Integer legal = Integer.valueOf(x);}
                    catch(NumberFormatException e){
                        throw new IllegalArgumentException("illegal operand/operator: " + x);
                    }
                    ExpressionNode operand = new ExpressionNode(x);
                    linky.addLast(operand);
System.out.println("linky size" + linky.size());

                }
            }
System.out.println("linky sizeMARTIn" + linky.size());
            if (linky.size()!=1){
                throw new IllegalArgumentException("invalid postfix expression");
            }
            else{root = linky.removeLast();}
            

                //commenting this out did nothing to the code. works fine
            /*for (int i = 0; i < linky.size(); i++) {
            ExpressionNode got = linky.get(i);
            String gotRight = got.right.data;
            String gotLeft = got.left.data;
            String gotData = got.data;
            System.out.print("linky" + gotRight + " " + gotLeft + " " + gotData);
            }*/

//if (root != null){System.out.println("rootNULL");}

//String rootLeft = root.data;
//System.out.println("rootLeft: " + rootLeft);
    }//end of constructor

        //is or is not operatorM METHOD
    private boolean operatorM(String x){
        return x.equals("+") || x.equals("-") || x.equals("*") || x.equals("/");
    }

//throw new IllegalArgumentException("illegal operator");
    
    @Override
        //eval methods
    public int eval(){
        return eval(root);
        }
        private int eval(ExpressionNode lump){
            if(lump == null){
                return -1; // -1 or 0?????????
            }
            if(lump.left == null && lump.right == null){
                return Integer.valueOf(lump.data); //wrapper class attempt
            }
            int leftO = eval(lump.left);
            int rightO = eval(lump.right);
            
            switch(lump.data){
                case "+":
                    return leftO + rightO;
                case "-":
                    return leftO - rightO; 
                case "*":
                    return leftO * rightO;
                case "/":
                    return leftO / rightO;
                default:
                    return 0; //RETURN - 1 OR 0?????

                }
            }
    

    @Override
        //postfix methods
	public String postfix(){
        StringBuilder bob = new StringBuilder();
        postfix(root, bob);
        return bob.toString();
    }
        private void postfix(ExpressionNode lump, StringBuilder bob){
            if(lump == null){
//System.out.println("postfix: NULL ");
                return;
            }
//System.out.println("postfix: notnull ");
            postfix(lump.left, bob);
            postfix(lump.right, bob);
            bob.append(lump.data).append(" ");
//System.out.println("bob: " + bob);
        }
    
        //prefix methods
	public String prefix(){
        StringBuilder bob = new StringBuilder();
        prefix(root, bob);
        return bob.toString();
        }
        private void prefix(ExpressionNode lump, StringBuilder bob){
            if(lump == null){
                return;
            }
            bob.append(lump.data).append(" ");
            prefix(lump.left, bob);
            prefix(lump.right, bob);
        }

        //infix methods
	public String infix(){
        StringBuilder bob = new StringBuilder();
        infix(root, bob);
        return bob.toString();
    }
        private void infix(ExpressionNode lump, StringBuilder bob){
            if(lump==null){
                return;
            }
            if(lump.left != null || lump.right != null){
                bob.append("(");
            }
            infix(lump.left, bob);
            bob.append(lump.data).append(" ");
            infix(lump.right, bob);
            if(lump.left !=null || lump.right != null){
                bob.append(")");
            }
        }

}