import java.util.LinkedList;

public class MainP1{
    public static void main(String[] args){
        /*
        String expression = "5 6 + x";
        ExpressionTree testTree = new ExpressionTree(expression);
        
        String post = testTree.postfix();
        String prefix = testTree.prefix();
        String infix = testTree.infix();
        int eval = testTree.eval();

        System.out.println("postfix:" + post);
        System.out.println("prefix:" + prefix);
        System.out.println("infix:" + infix);
        System.out.println("eval:" + eval);
        */

        BetterBST<Integer> tree2 = new BetterBST<>();
        
        /*
        tree2.insert(3);
        tree2.insert(5);
        tree2.insert(13);
        tree2.insert(6);
        tree2.insert(1);
        tree2.insert(23);
        */
        tree2.insert(54);
        tree2.insert(2);
        tree2.insert(7);
        tree2.insert(-2);
        tree2.insert(3);
        tree2.insert(23);

        
        int hI = tree2.height();
        Integer imbi = tree2.imbalance();
        Integer sGT = tree2.smallestGreaterThan(5);
        LinkedList<BinarySearchTree.BinaryNode<Integer>> answerLinky = tree2.levelOrderTraversal();

        //System.out.println("trees: " + tree2.root.data);
      //System.out.println("trees: " + tree2.root.right.right.data);
        System.out.println("height: " + hI);
        System.out.println("imbalance: " + imbi);
        System.out.println("sGT: " + sGT);

                System.out.println("traversal: ");
                if (answerLinky != null){
            for (BinarySearchTree.BinaryNode<Integer> node : answerLinky) {
                        System.out.print(node.data + ", ");
                    }
                }
            System.out.println("NEXT");
        BinarySearchTree<Integer> mirrah = tree2.mirror();
        LinkedList<BinarySearchTree.BinaryNode<Integer>> meerah = mirrah.levelOrderTraversal();

                System.out.println("mirror: ");
            for (BinarySearchTree.BinaryNode<Integer> x : meerah) {
                        System.out.print(x.data + ", ");
                    }

        
    }
}