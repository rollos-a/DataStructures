import java.util.LinkedList;

public class BetterBST<T extends Comparable<? super T>> extends BinarySearchTree<T>{

    @Override
    public int height(){
        return height(root); //xxxxxxxxxxxxxx
    }
        private int height(BinaryNode<T> node){
            if (node == null){
                return -1;
            }
            int leftH = height(node.left);
            int rightH = height(node.right);
            return 1 +(Math.max(leftH, rightH));

        }

    @Override
    public T imbalance(){
        return imbalance(root);
    }
        private T imbalance(BinaryNode<T> root){
                //empty tree
            if (root==null){return null;}

            int heightL = height(root.left);
            int heightR = height(root.right);
            if(Math.abs(heightL-heightR) > 1){
                return root.data;
            }

            T balanceL = imbalance(root.left);
            T balanceR = imbalance(root.right);
            if(balanceL != null){
                return balanceL;
            }
            if(balanceR != null){
                return balanceR;
            }
            return null; //xxxxxxxxx place holder return statement
            
        }

    @Override
    public T smallestGreaterThan(T x){
        return smallestGreaterThan(x, root);
    }
        private T smallestGreaterThan(T x, BinaryNode<T> node){
                //if empty tree
            if (root == null){return null;}
            BinaryNode<T> nodeNext = root;
            T answer = null;
            while(nodeNext != null){
                if(x.compareTo(nodeNext.data)<0){
                    answer = nodeNext.data;
                    nodeNext = nodeNext.left;
                }
                else{nodeNext=nodeNext.right;}
            }
            return answer;
        }




	@Override
    public LinkedList<BinaryNode<T>> levelOrderTraversal(){
            //linkedList which will provide the answer
        LinkedList<BinaryNode<T>> answerLinky = new LinkedList<>();
            //linkedList with the level of the BST we are currently at
        LinkedList<BinaryNode<T>> currentLevel = new LinkedList<>();
            //empty tree
        if(root == null){
            answerLinky = null;
            return answerLinky;}

        currentLevel.add(root); //to start us off
            while(!currentLevel.isEmpty()){
                BinaryNode<T> currentNode = currentLevel.remove();
                answerLinky.add(currentNode); //for the new level
            
                    //take care of right and left node traversl in rec
                if(currentNode.left != null){currentLevel.add(currentNode.left);}
                if(currentNode.right != null){currentLevel.add(currentNode.right);}
            }

        return answerLinky;
    }

    @Override
    public BinarySearchTree<T> mirror(){
        
        BetterBST<T> mirror = new BetterBST<>();
        mirror.root = mirror(root);
        return mirror;
    }
        private BinaryNode<T> mirror(BinaryNode<T> root){//(BinaryNode<T> currentNode, BinarySearchTree<T> mirror){
                //empty tree
            if(root == null){return null;}
            
            BinaryNode<T> mirrorN = new BinaryNode<>(root.data);
            mirrorN.left = mirror(root.right);
            mirrorN.right = mirror(root.left);
            /*if (currentNode != null){
                //BinaryNode<T> mirrorN = new BinaryNode<>(currentNode.data);
                mirrorN.left = mirror(currentNode.right, mirror);
                mirrorN.right = mirror(currentNode.left, mirror);

                //mirror.insert(mirrorN.data);
                //mirror(currentNode.right, mirror);
                //mirror(currentNode.left, mirror);
                return mirror;
            }*/
            return mirrorN;
        }

}