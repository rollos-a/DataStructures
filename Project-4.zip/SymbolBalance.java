// Java util imports
import java.util.Stack;
import java.util.Scanner;

// IO custom imports
import java.io.File;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;


public class SymbolBalance implements SymbolBalanceInterface{ 
    private String fileName;
    private File file;
    private Stack<Character> openStack;
    private Stack<Integer> lineStack;
    private BalanceError error;


        //constructor 
    public SymbolBalance(String fileName){//iki MismatchError mismatch put in?
        this.fileName = fileName;
        this.openStack = new Stack<>(); //iki
        this.lineStack = new Stack<>();//iki
        this.error = error;
        //MismatchError mismatchError = new MismatchError(MismatchError lineNumber, MismatchError currentSymbol, MismatchError symbolPopped);
        //SymbolBalanceInterface symbolInterface = mismatchError;

        //this.TestSymbolBalance(this.fileName); //took this out 9pm
    }   
    //setFile method from interface
    public void setFile(String fileName){
        file = new File(fileName);
    }
        //the original below taken out 9pm
    //public BalanceError checkFile() {
    //    return null;
    //}
    
    public BalanceError checkFile(){
        //File file = new File("/home/codio/workspace/TestFiles/Test1.java")
        File file = new File(fileName);

        try {
            try(BufferedReader br = new BufferedReader(new FileReader(file))) {
                String currentLine;
                //boolean commentedSection = false;
                int currentLineNumber = 0; 
                boolean quotation = false;
                boolean block = false; //hope

                while((currentLine = br.readLine()) != null) {
                            //System.out.println(currentLine); //-> prints out everything line by line
                    final int currentLineSize = currentLine.length();
                    ++currentLineNumber;
                    boolean charEvaled; //hope 5:57
                    int sizeOfStack;

                    for(int i = 0; i < currentLineSize; ++i) {
                        char currentSymbol = currentLine.charAt(i);
                        charEvaled = false;
            //System.out.println(currentSymbol);
                                        //System.out.println(currentSymbol);
                           
                           //checks EMPTYstack
                            //checks for doubleSlash and blockComment, and if TRUE, sets i == currentLineSize
                                    //check for OPEN block comment
                                if (currentSymbol == '*' && i != 0 && quotation == false && block == false && charEvaled == false){ //hope changes here
                                    if (currentLine.charAt(i-1) == '/'){
                                        charEvaled = true;
                                        block = true; //hope
                                        this.openStack.push('*');
                                        this.lineStack.push(currentLineNumber);

                                        //System.out.println("Opened block, line: " + currentLineNumber + " block: " + block);
                                    }
                                }
                                if (currentSymbol == '/' && quotation == false && block == true && charEvaled == false){ ///////hope changes here
                                    if (currentLine.charAt(i-1) == '*'){                        //hope changes here
                                        charEvaled = true;
                                        block = false;                                          //hope changes here
                                        this.openStack.pop();                                   //hope changes here
                                        this.lineStack.pop();                                   //hope changes here

                                        //System.out.println("Closed block, line: " + currentLineNumber + " block: " + block); //hope changes here
                                    }
                                }
                                    //true false QUOTES
                                if (currentSymbol == '\"' && quotation == false && block == false && charEvaled == false){ //hope changes here
                                    charEvaled = true;
                                    quotation = true;
                                    this.openStack.push(currentSymbol);
                                    this.lineStack.push(currentLineNumber);
                                    //System.out.print("open quotes line: " + currentLineNumber  + " quotes: " + quotation);
                                }
                                if (currentSymbol == '\"' && quotation == true && block == false && charEvaled == false){ //hope changes here
                                    charEvaled = true;
                                    quotation = false;
                                    this.openStack.pop();
                                    this.lineStack.pop();                                               //hope changes here
                                    //System.out.print("close quotes line: " + currentLineNumber + " quotes: " + quotation); //hope changes here
                                }

                                    //pushes big 3
                        //System.out.println("block: " + block);
                                if ((currentSymbol == '{' || currentSymbol == '[' || currentSymbol == '(') && (quotation == false && block == false && charEvaled == false)){ //hope changes here
                        //System.out.println("here");
                                    charEvaled = true;
                                    this.openStack.push(currentSymbol);
                                    this.lineStack.push(currentLineNumber);
                                    //System.out.print("Pushed: " + currentSymbol + " at line: " + currentLineNumber); //hope changes here
                                }
                                    //ERROR EmptyStackError
                                if ((currentSymbol == '}' || currentSymbol == ']' || currentSymbol == ')') && this.openStack.empty() == true && quotation == false && block == false && charEvaled == false){ //hope changes here
                                    //System.out.println("openStack Empty?" + this.openStack.empty() + " char being invest " + currentSymbol); //hope changes here
                                    //System.out.println("EmptyStackError line: " + currentLineNumber); //hope changes here
                                    return new EmptyStackError(currentLineNumber);
                                }
                                                                                        //hopes changes here (deleted openstack NOT empty if-statement)
                                    //looking for "" or * NOT on the stack
                        //System.out.println("is");
                                if (quotation == false && block == false && charEvaled == false && this.openStack.empty() == false){
                        //System.out.println("pie");
                                        //Mismatch calls OR pop calls
                                            //   {}
                                    if (currentSymbol == '}' && this.openStack.empty() == false && charEvaled == false){
                                        if(this.openStack.peek() == '{'){
                                            charEvaled = true;
                                            this.openStack.pop();
                                            this.lineStack.pop();
                                            //System.out.println("popped {}" + currentLineNumber);
                                            //System.out.println("stack empty?: " + this.openStack.empty());
                                        }
                                    }
                                    if(currentSymbol == '}' && this.openStack.empty() == false && charEvaled == false){
                                        if (this.openStack.peek() != '{'){
                                            //if (this.openStack.peek() != '{' && charEvaled == false){
                                            //System.out.println("Mismatch error line: " + currentLineNumber);
                                            //MismatchError
                                            char symbolPopped = this.openStack.pop();
                                            return new MismatchError(currentLineNumber, currentSymbol, symbolPopped);
                                        }
                                    }
                                            //    []
                                    if(currentSymbol == ']' && this.openStack.empty() == false && charEvaled == false){
                                        if (this.openStack.peek() == '['){
                                            charEvaled = true;
                                            this.openStack.pop();
                                            this.lineStack.pop();
                                            //System.out.println("popped []");
                                        }
                                    }
                                    if(currentSymbol == ']' && this.openStack.empty() == false && charEvaled == false){
                                        if (this.openStack.peek() != '['){
                                            //System.out.println("Mismatch error line: " + currentLineNumber);
                                            //MismatchError
                                            char symbolPopped = this.openStack.pop();
                                            return new MismatchError(currentLineNumber, currentSymbol, symbolPopped);
                                        }
                                    }
                                            //    ()
                                    if(currentSymbol == ')' && this.openStack.empty() == false && charEvaled == false){
                                        if(this.openStack.peek() == '('){
                                            charEvaled = true;
                                            this.openStack.pop();
                                            this.lineStack.pop();
                                            //System.out.println("popped ()");
                                        }
                                    }
                                    if(currentSymbol == ')' && this.openStack.empty() == false && charEvaled == false){
                                        if (this.openStack.peek() != '('){
                                            //System.out.println("Mismatch error line: " + currentLineNumber);
                                            //MismatchError
                                            char symbolPopped = this.openStack.pop();
                                            return new MismatchError(currentLineNumber, currentSymbol, symbolPopped);
                                        }
                                    }
                                }//<-- INSide ends peeking check for NOT* and "" // doing mismatch errors + popping when 3=3
                            //System.out.println("Yo");
                            //}<-- INSide 
                    }//<-- for int ENDS INSIDE HERE
                    //System.out.println("YUMMY");
                    
                }// <--- while closed here
                //System.out.println("size stack" + this.openStack.size() + "BOOLEANempty " + this.openStack.empty());
                
                int sizeOfStack;
                sizeOfStack = this.openStack.size();
                
                
                    //return NonEmptyStackError
                
                if (this.openStack.empty() == false){
                        char topOfStack = this.openStack.pop();
        //System.out.println("stack size" + sizeOfStack);
                        return new NonEmptyStackError(topOfStack, sizeOfStack);
                    }
                    else if(this.openStack.empty() == true){
                        return null;
                    }
            }// <-- while
            //catch(IOException e) {e.printStackTrace();} 
            //return null;
        } 
        catch(IOException e) {e.printStackTrace();} 
        return null;
    }//<-- method closes
        //catch(IOException e) {e.printStackTrace();} 
        //return null;
}
                        // /home/codio/workspace/TestFiles/Test1.java PASS
                        // /home/codio/workspace/TestFiles/Test2.java PASS
                        // /home/codio/workspace/TestFiles/Test3.java PASS 7:28
                        // /home/codio/workspace/TestFiles/Test4.java PASS
                        // /home/codio/workspace/TestFiles/Test5.java PASS
                        // /home/codio/workspace/TestFiles/Test6.java half pass