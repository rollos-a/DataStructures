import java.util.Scanner;
import java.util.Stack;

public class TwoStackQueue<T> implements TwoStackQueueInterface<T>{
      //instance variables
    private Stack<T> stack;
    private Stack<T> stackk;

      //constructor
    public TwoStackQueue(){
        stack = new Stack<>();
        stackk = new Stack<>();
    }
    public void enqueue(T item){
        stack.push(item);
    }
    public T dequeue(){
        if (stackk.empty()){
            while (!stack.empty()){
                stackk.push(stack.pop());
            }
        }
        return stackk.pop();
    }
    public boolean isEmpty(){
        return stack.empty() && stackk.empty();
    }
    public int size(){
        return stack.size() + stackk.size();
    }
    /*
    public static void main(String[] args){
        TwoStackQueue<String> queue = new TwoStackQueue<>();
        queue.enqueue("we");
        queue.enqueue("hold");
        queue.enqueue("these");
        queue.enqueue("truths");
        queue.enqueue("to");
        queue.enqueue("be");
        queue.enqueue("self");
        queue.enqueue("evident");
        queue.enqueue("that");

        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        //System.out.println(queue.dequeue());
        
    }
    */
}