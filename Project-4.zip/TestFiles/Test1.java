/*this tests an unbalanced [ operator*/
public class Test1 {
//	

	/* this is the main method */
	public static void main(String[ ) args) {
		String ghana = "hello";
		int test = testing();
	}

	public int testing() {
		/*checking this too */
		/* and this */ 
		return 1; 
	}


}