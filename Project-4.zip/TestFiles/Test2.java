/* this is to test whether the program can deal with an imbalance of { */
public class Test2 {
	public static void main(String[] args) {
		boolean haveYouWatchedHamiltonYet = true;
		int theSchuylerSisters = 3; 
		int alexanderhamilton = 1;
		int aaronburr = 1;

		boolean amIinTheRoom = theRoomWhereItHappens();
		/* imbalanced { test */
		{

	}

	/*just a general comment */ 
	public boolean theRoomWhereItHappens() {
		boolean intheRoomWhereItHappens = false;
		boolean isHappyAboutThis = false;
		return intheRoomWhereItHappens && isHappyAboutThis;

	}
}