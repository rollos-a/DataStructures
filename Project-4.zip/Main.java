import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.print("Enter a filename: ");
        Scanner scanner1 = new Scanner(System.in);
        String filename = scanner1.nextLine();

        System.out.println(filename + "BOGGLE");
        
        SymbolBalance symbolBalance = new SymbolBalance(filename);

        //checkFile

        symbolBalance.setFile(filename);
        System.out.println(symbolBalance.checkFile());
    }
}

/*
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.print("Enter a filename: ");
        Scanner scanner1 = new Scanner(System.in);
        String filename = scanner1.nextLine();

        System.out.println(filename + "BOGGLE");
        
        SymbolBalance symbolBalance = new SymbolBalance(filename);

        //checkFile

        symbolBalance.setFile(filename);
        System.out.println(symbolBalance.checkFile());
    }
}

*/
