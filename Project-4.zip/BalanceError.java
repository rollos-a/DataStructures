public interface BalanceError {

    ///public NonEmptyStackError(char topOfStack, int sizeOfStack);
    //public String toString()

	//public MismatchError(int lineNumber, char currentSymbol, char symbolPopped)












    // returns either MismatchError(int lineNumber, char currentSymbol, char symbolPopped)
    //                EmptyStackError(int lineNumber), 
    //                NonEmptyStackError(char topElement, int sizeOfStack). 
    // All three classes implement BalanceError


}
